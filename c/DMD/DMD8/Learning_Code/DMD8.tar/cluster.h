extern double get_gr(void);
extern int init_clusters(void);






