extern void close_corr_func(void);
extern void cor_func(double delta);
extern int init_corr_func(void);
