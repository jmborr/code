int isHBRelated(atom*, atom*);
int process_hb(atom*, int, int , int , double , double, double, double,
	       int, int, int);
int checkAssociatedBond(atom*, int, atom*, int);
int checkDessociatedBond(atom*, int, atom*, int);
