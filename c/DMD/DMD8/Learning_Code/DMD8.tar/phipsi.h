void init_phipsi();
void process_phipsi();
